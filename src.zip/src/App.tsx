import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useUIStore } from '@/store/uiStore';
import type { View } from '@/types';
import { useRegisterSW } from 'virtual:pwa-register/react';
import Auth from '@/components/Auth';
import DayPage from '@/pages/index';
import WeekPage from '@/pages/week';
import MonthPage from '@/pages/month';
import AnalyticsPage from '@/pages/analytics';
import HabitsPage from '@/pages/habits';
import FastingPage from '@/pages/fasting';
import SettingsPage from '@/pages/settings';
import LibraryPage from '@/pages/library';
import DocumentsPage from '@/pages/documents';
import TimerOverlay from '@/components/planner/TimerOverlay';
import { useSupabaseRealtime } from '@/hooks/useSupabaseRealtime';
import type { Session } from '@supabase/supabase-js';

function AuthenticatedApp() {
  const { isDarkMode, activeView, setView, toggleDark, docsNewBadge, dismissDocsBadge } =
    useUIStore();
  const { needRefresh, updateServiceWorker } = useRegisterSW();

  useSupabaseRealtime();

  const desktopTabs: { view: View; label: string; badge?: boolean }[] = [
    { view: 'day', label: 'Day' },
    { view: 'week', label: 'Week' },
    { view: 'month', label: 'Month' },
    { view: 'analytics', label: '📊' },
    { view: 'habits', label: 'Habits' },
    { view: 'fasting', label: '🕐 Fast' },
    { view: 'documents', label: '📄 Docs', badge: docsNewBadge },
    { view: 'library', label: '📚' },
    { view: 'settings', label: '⚙️' },
  ];

  const mobileTabs: { view: View; label: string; icon: string; badge?: boolean }[] = [
    { view: 'day', label: 'Day', icon: '📅' },
    { view: 'week', label: 'Week', icon: '📆' },
    { view: 'month', label: 'Month', icon: '🗓' },
    { view: 'habits', label: 'Habits', icon: '✅' },
    { view: 'documents', label: 'Docs', icon: '📄', badge: docsNewBadge },
    { view: 'fasting', label: 'Fast', icon: '🕐' },
  ];

  const handleNavClick = (view: (typeof desktopTabs)[number]['view']) => {
    setView(view);
    if (view === 'documents') dismissDocsBadge();
  };

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: 'var(--df-bg)', paddingTop: 'env(safe-area-inset-top)' }}
    >
      {/* ── Desktop top nav ── */}
      <nav
        className="hidden md:flex items-center gap-2 px-4 py-2 border-b"
        style={{ background: 'var(--df-surface)', borderColor: 'var(--df-border)' }}
      >
        <span className="font-bold text-base text-white shrink-0 mr-2">DayFlow</span>

        <div className="flex gap-1.5 overflow-x-auto scrollbar-none flex-1">
          {desktopTabs.map(({ view, label, badge }) => (
            <button
              key={view}
              onClick={() => handleNavClick(view)}
              className="relative text-sm font-medium whitespace-nowrap px-3 py-1.5 rounded-md transition-all"
              style={{
                background: activeView === view ? 'var(--df-accent)' : 'var(--df-surface2)',
                color: activeView === view ? '#fff' : 'var(--df-muted)',
                border: `1px solid ${activeView === view ? 'var(--df-accent)' : 'var(--df-border)'}`,
              }}
            >
              {label}
              {badge && (
                <span
                  className="absolute -top-1.5 -right-1 text-white text-[8px] font-bold px-1 py-px rounded-sm leading-none"
                  style={{ background: 'var(--df-green)' }}
                >
                  NEW
                </span>
              )}
            </button>
          ))}
          {needRefresh[0] && (
            <button
              onClick={() => updateServiceWorker(true)}
              className="text-xs px-2 py-1 rounded text-white whitespace-nowrap"
              style={{ background: 'var(--df-green)' }}
            >
              Update
            </button>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={toggleDark}
            className="w-8 h-8 flex items-center justify-center rounded-md text-sm transition-colors hover:bg-white/10"
            style={{ color: 'var(--df-muted)' }}
          >
            {isDarkMode ? '☀️' : '🌙'}
          </button>
          <button
            onClick={() => supabase.auth.signOut()}
            className="w-8 h-8 flex items-center justify-center rounded-md text-sm transition-colors hover:bg-white/10"
            style={{ color: 'var(--df-muted)' }}
            title="Sign out"
          >
            🚪
          </button>
        </div>
      </nav>

      {/* ── Mobile top bar ── */}
      <div
        className="flex md:hidden items-center justify-between px-4 py-2.5 border-b"
        style={{ background: 'var(--df-surface)', borderColor: 'var(--df-border)' }}
      >
        <span className="font-bold text-base text-white">DayFlow</span>
        <div className="flex items-center gap-1">
          {(['analytics', 'library', 'settings'] as const).map((v) => (
            <button
              key={v}
              onClick={() => handleNavClick(v)}
              className="w-8 h-8 flex items-center justify-center rounded-md text-sm transition-colors"
              style={{
                background: activeView === v ? 'var(--df-accent)' : 'transparent',
                color: activeView === v ? '#fff' : 'var(--df-muted)',
              }}
            >
              {v === 'analytics' ? '📊' : v === 'library' ? '📚' : '⚙️'}
            </button>
          ))}
          <button
            onClick={() => supabase.auth.signOut()}
            className="w-8 h-8 flex items-center justify-center rounded-md text-sm"
            style={{ color: 'var(--df-muted)' }}
          >
            🚪
          </button>
        </div>
      </div>

      {/* ── Main content ── */}
      {activeView === 'documents' ? (
        <main
          className="flex-1 overflow-y-auto"
          style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 70px)' }}
        >
          <DocumentsPage />
        </main>
      ) : (
        <main
          className="flex-1 p-3 overflow-y-auto"
          style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 70px)' }}
        >
          {activeView === 'day' && <DayPage />}
          {activeView === 'week' && <WeekPage />}
          {activeView === 'month' && <MonthPage />}
          {activeView === 'analytics' && <AnalyticsPage />}
          {activeView === 'habits' && <HabitsPage />}
          {activeView === 'fasting' && <FastingPage />}
          {activeView === 'library' && <LibraryPage />}
          {activeView === 'settings' && <SettingsPage />}
        </main>
      )}

      {/* ── Mobile bottom nav ── */}
      <div
        className="fixed bottom-0 left-0 right-0 md:hidden z-40 flex border-t"
        style={{
          background: 'var(--df-surface)',
          borderColor: 'var(--df-border)',
          paddingBottom: 'env(safe-area-inset-bottom)',
        }}
      >
        {mobileTabs.map(({ view, label, icon, badge }) => (
          <button
            key={view}
            onClick={() => handleNavClick(view)}
            className="flex-1 flex flex-col items-center justify-center py-2 gap-1 relative transition-colors"
            style={{ color: activeView === view ? 'var(--df-accent)' : 'var(--df-muted)' }}
          >
            <div
              className="w-8 h-7 rounded flex items-center justify-center text-base transition-all"
              style={{ background: activeView === view ? 'var(--df-accent)' : 'transparent' }}
            >
              {icon}
            </div>
            <span className="text-[10px] font-medium">{label}</span>
            {badge && (
              <span
                className="absolute top-0.5 right-1/4 text-white text-[7px] font-bold px-1 rounded-sm leading-tight"
                style={{ background: 'var(--df-green)' }}
              >
                NEW
              </span>
            )}
          </button>
        ))}
      </div>

      <TimerOverlay />
    </div>
  );
}

export default function App() {
  const { isDarkMode } = useUIStore();
  const [session, setSession] = useState<Session | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setChecking(false);
    });
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
  }, [isDarkMode]);

  if (checking)
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-bg">
        <p className="text-brand-muted">Loading…</p>
      </div>
    );

  if (!session) return <Auth />;

  return <AuthenticatedApp />;
}
