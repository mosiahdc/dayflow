import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnon = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnon) {
    throw new Error(
        'Missing Supabase environment variables. Check your .env.local file.'
    );
}

export const supabase = createClient(supabaseUrl, supabaseAnon);