import { useState, useCallback, useEffect, lazy, Suspense } from 'react';
import { supabase } from '@/lib/supabase';
import { useDocumentStore } from '@/store/documentStore';
import type { Document } from '@/types';

const PdfReader = lazy(() => import('./PdfReader'));
const EpubReader = lazy(() => import('./EpubReader'));

interface Props {
  doc: Document;
  onClose: () => void;
}

export default function DocumentReader({ doc, onClose }: Props) {
  const { updateLastPage } = useDocumentStore();

  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [epubBlob, setEpubBlob] = useState<Blob | null>(null);
  const [loadingState, setLoadingState] = useState<'fetching' | 'ready' | 'error'>('fetching');
  const [loadingMsg, setLoadingMsg] = useState('Loading…');

  const [currentPage, setCurrentPage] = useState(doc.lastPage || 1);
  const [totalPages, setTotalPages] = useState(doc.pageCount ?? 0);
  const [epubCfi, setEpubCfi] = useState<string | undefined>();

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setLoadingState('fetching');
      setLoadingMsg('Loading…');

      try {
        if (doc.fileType === 'pdf') {
          // PDF: signed URL is fine — pdf.js fetches the whole file itself
          // and never makes relative sub-requests.
          const { data, error } = await supabase.storage
            .from('documents')
            .createSignedUrl(doc.filePath, 60 * 60);

          if (error || !data?.signedUrl) throw new Error(error?.message ?? 'No signed URL');

          if (!cancelled) {
            setPdfUrl(data.signedUrl);
            setLoadingState('ready');
          }
          return;
        }

        // EPUB — download raw bytes via the Supabase JS client.
        // This avoids the CORS issue that fetch(signedUrl) hits from localhost:
        // the JS client sends auth via the Authorization header, not a query
        // param, so Supabase Storage allows the request without a CORS preflight
        // to a signed-URL endpoint.
        //
        // We pass the Blob directly to EpubReader instead of converting to
        // base64. EpubReader calls book.open(blob) manually (bypassing the
        // ePub() factory's swallowed-error catch) so any real parse error is
        // surfaced instead of the generic "[object Blob]" message.
        setLoadingMsg('Downloading book…');

        const { data: blob, error } = await supabase.storage
          .from('documents')
          .download(doc.filePath);

        if (error || !blob) throw new Error(error?.message ?? 'Download failed');

        if (!cancelled) {
          setEpubBlob(blob);
          setLoadingState('ready');
        }
      } catch (e) {
        console.error('Document load failed:', e);
        if (!cancelled) setLoadingState('error');
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [doc.filePath, doc.fileType]);

  const handlePageChange = useCallback(
    (page: number) => {
      setCurrentPage(page);
      updateLastPage(doc.id, page);
    },
    [doc.id, updateLastPage]
  );

  const handleEpubLocation = useCallback(
    (cfi: string) => {
      setEpubCfi(cfi);
      updateLastPage(doc.id, currentPage);
    },
    [doc.id, updateLastPage, currentPage]
  );

  const handleTotalPages = useCallback((total: number) => {
    setTotalPages(total);
  }, []);

  const progress = totalPages > 0 ? Math.round((currentPage / totalPages) * 100) : 0;

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="bg-gray-800 border-b border-gray-700 px-3 py-2.5 flex items-center gap-3 shrink-0">
        <button
          onClick={onClose}
          className="bg-gray-700 hover:bg-gray-600 text-white rounded-lg w-8 h-8 flex items-center justify-center text-lg leading-none transition-colors shrink-0"
          aria-label="Back to library"
        >
          ‹
        </button>
        <div className="flex-1 min-w-0">
          <p className="text-white text-xs font-semibold truncate leading-tight">{doc.title}</p>
          <p className="text-gray-500 text-[10px] uppercase leading-tight mt-0.5">{doc.fileType}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {doc.fileType === 'pdf' && totalPages > 0 && (
            <span className="text-gray-400 text-xs hidden sm:block">
              {currentPage} / {totalPages}
            </span>
          )}
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full
              ${
                progress >= 100
                  ? 'bg-brand-green/20 text-brand-green'
                  : 'bg-brand-accent/20 text-brand-accent'
              }`}
          >
            {progress >= 100 ? '✓ Done' : `${progress}%`}
          </span>
        </div>
      </div>

      {/* Reader area */}
      <div className="flex-1 overflow-hidden">
        {loadingState === 'fetching' && (
          <div className="flex items-center justify-center h-full bg-gray-900">
            <div className="text-center">
              <div className="w-8 h-8 border-2 border-brand-accent border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="text-white text-sm">{loadingMsg}</p>
            </div>
          </div>
        )}

        {loadingState === 'error' && (
          <div className="flex items-center justify-center h-full bg-gray-900 p-8">
            <div className="text-center max-w-xs">
              <p className="text-4xl mb-4">⚠️</p>
              <p className="text-white text-sm font-semibold mb-2">Could not load document</p>
              <p className="text-gray-400 text-xs mb-4">Check your connection and try again.</p>
              <button onClick={onClose} className="text-brand-accent text-sm hover:underline">
                ← Back to library
              </button>
            </div>
          </div>
        )}

        {loadingState === 'ready' && doc.fileType === 'pdf' && pdfUrl && (
          <Suspense
            fallback={
              <div className="flex items-center justify-center h-full bg-gray-900">
                <p className="text-white text-sm animate-pulse">Initializing PDF reader…</p>
              </div>
            }
          >
            <PdfReader
              url={pdfUrl}
              initialPage={doc.lastPage || 1}
              onPageChange={handlePageChange}
              onTotalPages={handleTotalPages}
            />
          </Suspense>
        )}

        {loadingState === 'ready' && doc.fileType === 'epub' && epubBlob && (
          <Suspense
            fallback={
              <div className="flex items-center justify-center h-full bg-white dark:bg-gray-900">
                <p className="text-brand-muted text-sm animate-pulse">Opening book…</p>
              </div>
            }
          >
            <EpubReader
              blob={epubBlob}
              {...(epubCfi !== undefined ? { initialCfi: epubCfi } : {})}
              onLocationChange={handleEpubLocation}
              onTotalLocations={handleTotalPages}
            />
          </Suspense>
        )}
      </div>
    </div>
  );
}
