import { useEffect, useRef, useState, useCallback } from 'react';
import { Book, Rendition } from 'epubjs';
import JSZip from 'jszip';
import type { NavItem } from 'epubjs';
import { useSwipe } from '@/hooks/useSwipe';

interface Props {
  blob: Blob;
  initialCfi?: string | undefined;
  onLocationChange: (cfi: string) => void;
  onTotalLocations: (total: number) => void;
}

export default function EpubReader({
  blob,
  initialCfi,
  onLocationChange,
  onTotalLocations,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const bookRef = useRef<Book | null>(null);
  const renditionRef = useRef<Rendition | null>(null);
  const [toc, setToc] = useState<NavItem[]>([]);
  const [showToc, setShowToc] = useState(false);
  const [progress, setProgress] = useState(0);
  const [loading, setLoading] = useState(true);
  const [fontSize, setFontSize] = useState(100);
  const [error, setError] = useState('');

  const goNext = useCallback(() => renditionRef.current?.next(), []);
  const goPrev = useCallback(() => renditionRef.current?.prev(), []);

  const swipeHandlers = useSwipe({
    onSwipeLeft: goNext,
    onSwipeRight: goPrev,
    threshold: 40,
    maxVertical: 100,
  });

  useEffect(() => {
    if (!containerRef.current || !blob) return;

    setLoading(true);
    setError('');

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const book = new (Book as any)() as Book;
    bookRef.current = book;

    const rendition = book.renderTo(containerRef.current, {
      width: '100%',
      height: '100%',
      spread: 'none',
      flow: 'paginated',
    });
    renditionRef.current = rendition;

    rendition.themes.fontSize(`${fontSize}%`);
    rendition.themes.default({
      body: {
        'font-family': 'Georgia, "Times New Roman", serif',
        'line-height': '1.7',
        padding: '0 1.5rem',
      },
    });

    const openBook = async () => {
      // ── Diagnostic: read the zip ourselves first to verify the epub structure.
      // epub.js's "No RootFile Found" means container.xml was found but its
      // XML either failed to parse or has no <rootfile> element.
      // We use JSZip directly to check what's actually inside before handing
      // the blob to epub.js. This lets us fix encoding issues on the fly.
      let fixedBlob = blob;

      try {
        const zip = await JSZip.loadAsync(blob);
        const containerEntry = zip.file('META-INF/container.xml');

        if (!containerEntry) {
          // Some epubs use uppercase or a different path — try to find it
          const keys = Object.keys(zip.files);
          console.warn('[EpubReader] zip entries:', keys.slice(0, 20));
          throw new Error(
            'META-INF/container.xml not found in zip. Entries: ' + keys.slice(0, 10).join(', ')
          );
        }

        const containerXml = await containerEntry.async('string');
        console.log('[EpubReader] container.xml preview:', containerXml.slice(0, 500));

        // Check if DOMParser can actually parse it
        const doc = new DOMParser().parseFromString(containerXml, 'text/xml');
        const parseError = doc.querySelector('parsererror');
        if (parseError) {
          console.error('[EpubReader] container.xml parse error:', parseError.textContent);
          throw new Error(
            'container.xml is not valid XML: ' + parseError.textContent?.slice(0, 200)
          );
        }

        const rootfile = doc.querySelector('rootfile') ?? doc.getElementsByTagName('rootfile')[0];
        if (!rootfile) {
          console.error('[EpubReader] container.xml has no rootfile. Full content:', containerXml);
          throw new Error('container.xml has no <rootfile> element');
        }

        console.log('[EpubReader] rootfile path:', rootfile.getAttribute('full-path'));

        // Re-create the blob with the explicit epub MIME type so JSZip / epub.js
        // has the correct content-type hint when reading it internally.
        fixedBlob = new Blob([await blob.arrayBuffer()], { type: 'application/epub+zip' });
      } catch (diagErr) {
        console.error('[EpubReader] diagnostic failed:', diagErr);
        setError(diagErr instanceof Error ? diagErr.message : 'Could not read EPUB structure.');
        setLoading(false);
        return;
      }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (book as any)
        .open(fixedBlob)
        .then(() => {
          if (initialCfi) {
            return rendition.display(initialCfi).catch(() => rendition.display());
          }
          return rendition.display();
        })
        .catch((e: unknown) => {
          console.error('epub open failed:', e);
          setError(
            e instanceof Error
              ? e.message
              : 'Could not parse this EPUB. It may be corrupted or DRM-protected.'
          );
          setLoading(false);
        });
    };

    openBook();

    rendition.on('rendered', () => setLoading(false));

    rendition.on('relocated', (location: { start: { cfi: string } }) => {
      onLocationChange(location.start.cfi);
      try {
        const result = book.locations.percentageFromCfi(location.start.cfi) as
          | number
          | Promise<number>;
        if (typeof result === 'number') {
          setProgress(Math.round(result * 100));
        } else if (result && typeof (result as Promise<number>).then === 'function') {
          (result as Promise<number>)
            .then((pct) => setProgress(Math.round(pct * 100)))
            .catch(() => {});
        }
      } catch {}
    });

    book.loaded.navigation.then((nav) => setToc(nav.toc)).catch(() => {});

    book.ready
      .then(() => {
        const gen = book.locations.generate(1024) as unknown;
        if (gen && typeof (gen as Promise<string[]>).then === 'function') {
          (gen as Promise<string[]>).then((locs) => onTotalLocations(locs.length)).catch(() => {});
        } else if (Array.isArray(gen)) {
          onTotalLocations((gen as string[]).length);
        }
      })
      .catch(() => {});

    return () => {
      try {
        book.destroy();
      } catch {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blob]);

  useEffect(() => {
    renditionRef.current?.themes.fontSize(`${fontSize}%`);
  }, [fontSize]);

  if (error) {
    return (
      <div className="flex-1 flex items-center justify-center bg-white dark:bg-gray-900 p-8">
        <div className="text-center max-w-xs">
          <p className="text-4xl mb-4">📖</p>
          <p className="text-sm font-semibold dark:text-white mb-2">Cannot open EPUB</p>
          <p className="text-xs text-brand-muted">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900">
      <div className="flex-1 relative overflow-hidden" {...swipeHandlers}>
        <button
          onClick={goPrev}
          className="absolute left-0 top-0 bottom-0 w-12 flex items-center justify-center z-10 opacity-0 hover:opacity-100 active:opacity-100 transition-opacity"
          aria-label="Previous page"
        >
          <div className="bg-brand-accent/80 rounded-r-xl h-20 w-8 flex items-center justify-center text-white text-xl">
            ‹
          </div>
        </button>
        <button
          onClick={goNext}
          className="absolute right-0 top-0 bottom-0 w-12 flex items-center justify-center z-10 opacity-0 hover:opacity-100 active:opacity-100 transition-opacity"
          aria-label="Next page"
        >
          <div className="bg-brand-accent/80 rounded-l-xl h-20 w-8 flex items-center justify-center text-white text-xl">
            ›
          </div>
        </button>

        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white dark:bg-gray-900 z-20">
            <p className="text-brand-muted text-sm animate-pulse">Opening book…</p>
          </div>
        )}

        <div ref={containerRef} className="w-full h-full" />

        {showToc && (
          <div className="absolute inset-0 bg-white dark:bg-gray-900 z-30 flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b dark:border-gray-700 shrink-0">
              <span className="font-semibold text-sm dark:text-white">Table of contents</span>
              <button
                onClick={() => setShowToc(false)}
                className="text-brand-muted text-lg leading-none"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {toc.length === 0 && (
                <p className="text-brand-muted text-xs text-center py-8">No table of contents.</p>
              )}
              {toc.map((item, i) => (
                <button
                  key={i}
                  onClick={() => {
                    renditionRef.current?.display(item.href);
                    setShowToc(false);
                  }}
                  className="w-full text-left px-4 py-3 text-sm dark:text-white border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                >
                  {item.label.trim()}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/40 text-white text-xs px-3 py-1.5 rounded-full pointer-events-none md:hidden opacity-50">
          swipe to turn page
        </div>
      </div>

      <div className="bg-gray-100 dark:bg-gray-800 border-t dark:border-gray-700 px-4 py-2 flex items-center gap-3 shrink-0">
        <button
          onClick={() => setShowToc(true)}
          className="text-xs text-brand-muted hover:text-brand-accent transition-colors shrink-0"
        >
          Contents
        </button>
        <div className="flex-1 h-1 bg-gray-300 dark:bg-gray-600 rounded-full">
          <div
            className="h-full rounded-full bg-brand-accent transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-gray-400 text-xs shrink-0">{progress}%</span>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => setFontSize((s) => Math.max(70, s - 10))}
            className="bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 w-7 h-7 rounded flex items-center justify-center text-xs font-bold"
            title="Smaller text"
          >
            A-
          </button>
          <button
            onClick={() => setFontSize((s) => Math.min(200, s + 10))}
            className="bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 w-7 h-7 rounded flex items-center justify-center text-xs font-bold"
            title="Larger text"
          >
            A+
          </button>
        </div>
      </div>
    </div>
  );
}
