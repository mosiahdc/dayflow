import { useState, useEffect, useCallback, useRef } from 'react';
import { Document as PDFDocument, Page, pdfjs } from 'react-pdf';
import { useSwipe } from '@/hooks/useSwipe';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';

// Set the worker source — must match installed react-pdf version
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

interface Props {
  url: string;
  initialPage: number;
  onPageChange: (page: number) => void;
  onTotalPages: (total: number) => void;
}

export default function PdfReader({ url, initialPage, onPageChange, onTotalPages }: Props) {
  const [numPages, setNumPages] = useState<number>(0);
  const [pageNumber, setPageNumber] = useState(initialPage || 1);
  const [scale, setScale] = useState(1.0);
  const [loading, setLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  const goNext = useCallback(() => {
    setPageNumber((p) => {
      const next = Math.min(p + 1, numPages);
      onPageChange(next);
      return next;
    });
  }, [numPages, onPageChange]);

  const goPrev = useCallback(() => {
    setPageNumber((p) => {
      const prev = Math.max(p - 1, 1);
      onPageChange(prev);
      return prev;
    });
  }, [onPageChange]);

  const swipeHandlers = useSwipe({
    onSwipeLeft: goNext,
    onSwipeRight: goPrev,
    threshold: 40,
    maxVertical: 100,
  });

  const onDocumentLoad = useCallback(
    ({ numPages: n }: { numPages: number }) => {
      setNumPages(n);
      onTotalPages(n);
      setLoading(false);
    },
    [onTotalPages]
  );

  // Calculate width to fill container
  const [containerWidth, setContainerWidth] = useState(600);
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setContainerWidth(el.clientWidth - 32);
    });
    ro.observe(el);
    setContainerWidth(el.clientWidth - 32);
    return () => ro.disconnect();
  }, []);

  const progress = numPages > 0 ? Math.round((pageNumber / numPages) * 100) : 0;

  return (
    <div className="flex flex-col h-full bg-gray-900">
      {/* Page area */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto flex items-start justify-center p-4 relative"
        {...swipeHandlers}
      >
        {/* Large tap targets for page turn on mobile */}
        <button
          onClick={goPrev}
          disabled={pageNumber <= 1}
          className="absolute left-1 top-1/2 -translate-y-1/2 w-8 h-20 bg-brand-accent/70 hover:bg-brand-accent rounded-xl flex items-center justify-center text-white text-xl z-10 disabled:opacity-20 transition-colors"
          aria-label="Previous page"
        >
          ‹
        </button>
        <button
          onClick={goNext}
          disabled={pageNumber >= numPages}
          className="absolute right-1 top-1/2 -translate-y-1/2 w-8 h-20 bg-brand-accent/70 hover:bg-brand-accent rounded-xl flex items-center justify-center text-white text-xl z-10 disabled:opacity-20 transition-colors"
          aria-label="Next page"
        >
          ›
        </button>

        {loading && (
          <div className="flex items-center justify-center h-64 w-full">
            <div className="text-white text-sm animate-pulse">Loading document…</div>
          </div>
        )}

        <PDFDocument
          file={url}
          onLoadSuccess={onDocumentLoad}
          onLoadError={() => setLoading(false)}
          loading={null}
          className="shadow-2xl"
        >
          <Page
            pageNumber={pageNumber}
            width={containerWidth * scale}
            renderAnnotationLayer
            renderTextLayer
            loading={
              <div
                className="bg-white rounded"
                style={{ width: containerWidth, height: containerWidth * 1.41 }}
              />
            }
          />
        </PDFDocument>

        {/* Swipe hint on mobile — shown briefly */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-black/50 text-white text-xs px-3 py-1.5 rounded-full pointer-events-none opacity-60 md:hidden">
          swipe to turn page
        </div>
      </div>

      {/* Bottom bar */}
      <div className="bg-gray-800 border-t border-gray-700 px-4 py-2 flex items-center gap-3 shrink-0">
        <span className="text-gray-400 text-xs">{pageNumber}</span>
        <div className="flex-1 h-1 bg-gray-600 rounded-full">
          <div
            className="h-full rounded-full bg-brand-accent transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-gray-400 text-xs">{numPages}</span>
        <span className="text-gray-500 text-xs ml-1">{progress}%</span>

        {/* Zoom controls — desktop */}
        <div className="hidden md:flex items-center gap-1 ml-2">
          <button
            onClick={() => setScale((s) => Math.max(0.5, s - 0.1))}
            className="bg-gray-700 text-gray-300 hover:text-white w-7 h-7 rounded flex items-center justify-center text-sm"
          >
            −
          </button>
          <span className="text-gray-400 text-xs w-10 text-center">{Math.round(scale * 100)}%</span>
          <button
            onClick={() => setScale((s) => Math.min(3, s + 0.1))}
            className="bg-gray-700 text-gray-300 hover:text-white w-7 h-7 rounded flex items-center justify-center text-sm"
          >
            +
          </button>
        </div>
      </div>
    </div>
  );
}
