import { useEffect, useRef, useState } from 'react';
import { useDocumentStore } from '@/store/documentStore';
import type { Document } from '@/types';

function fmtSize(bytes: number): string {
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function DocIcon({ type, color }: { type: 'pdf' | 'epub'; color: string }) {
  return (
    <div
      className="w-9 h-11 rounded flex items-center justify-center flex-shrink-0"
      style={{ backgroundColor: color }}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="white" opacity={0.85}>
        {type === 'epub' ? (
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
        ) : (
          <>
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <polyline points="14 2 14 8 20 8" fill="none" stroke="white" strokeWidth="1.5" />
          </>
        )}
      </svg>
    </div>
  );
}

const DOC_COLORS = [
  '#4F6EF7',
  '#10B981',
  '#F59E0B',
  '#EC4899',
  '#7C3AED',
  '#0D9488',
  '#EF4444',
  '#6366F1',
];

function getDocColor(index: number): string {
  return DOC_COLORS[index % DOC_COLORS.length] ?? '#4F6EF7';
}

interface Props {
  onOpen: (doc: Document) => void;
}

export default function DocumentLibrary({ onOpen }: Props) {
  const { documents, loading, uploading, fetchAll, uploadDocument, deleteDocument } =
    useDocumentStore();
  const [search, setSearch] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const filtered = documents.filter(
    (d) => !search || d.title.toLowerCase().includes(search.toLowerCase())
  );

  const handleFile = async (file: File) => {
    setUploadError('');
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'pdf' && ext !== 'epub') {
      setUploadError('Only PDF and EPUB files are supported.');
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      setUploadError('File must be under 50 MB.');
      return;
    }
    const title = file.name.replace(/\.(pdf|epub)$/i, '');
    await uploadDocument(file, title);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
        <div>
          <h1 className="text-lg font-bold dark:text-white">Documents</h1>
          <p className="text-xs text-brand-muted mt-0.5">
            {documents.length} file{documents.length !== 1 ? 's' : ''} · synced across devices
          </p>
        </div>
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="bg-brand-accent text-white rounded-lg px-4 py-2 text-sm font-semibold hover:opacity-90 disabled:opacity-50 shrink-0"
        >
          {uploading ? 'Uploading…' : '+ Upload PDF / EPUB'}
        </button>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const f = e.dataTransfer.files[0];
          if (f) handleFile(f);
        }}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-colors mb-4
          ${dragOver ? 'border-brand-accent bg-brand-accent/5' : 'border-gray-300 dark:border-gray-600 hover:border-brand-accent'}`}
      >
        <p className="text-sm text-brand-muted">
          {dragOver ? 'Drop to upload' : 'Drop PDF or EPUB here — or click to browse'}
        </p>
        <p className="text-xs text-brand-muted/60 mt-1">Max 50 MB</p>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.epub"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = '';
        }}
      />

      {uploadError && (
        <p className="text-red-500 text-xs mb-3 bg-red-50 dark:bg-red-900/20 px-3 py-2 rounded-lg">
          {uploadError}
        </p>
      )}

      {/* Search */}
      <input
        className="w-full border rounded-lg px-3 py-2 text-sm mb-4 dark:bg-gray-700 dark:text-white dark:border-gray-600"
        placeholder="Search documents…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {loading && (
        <div className="flex flex-col gap-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse bg-gray-100 dark:bg-gray-700 rounded-xl h-16" />
          ))}
        </div>
      )}

      {!loading && documents.length === 0 && (
        <div className="text-center py-16">
          <p className="text-4xl mb-3">📄</p>
          <p className="text-sm font-semibold dark:text-white">No documents yet</p>
          <p className="text-xs text-brand-muted mt-1">Upload a PDF or EPUB to get started</p>
        </div>
      )}

      {!loading && documents.length > 0 && (
        <div className="flex flex-col">
          {!search && (
            <p className="text-xs font-semibold text-brand-muted uppercase tracking-wide mb-2">
              Recent
            </p>
          )}
          {filtered.map((doc, i) => {
            const color = getDocColor(i);
            const pct = doc.pageCount ? Math.round((doc.lastPage / doc.pageCount) * 100) : 0;
            const complete = doc.pageCount != null && doc.lastPage >= doc.pageCount;
            const isConfirming = confirmDelete === doc.id;
            return (
              <div
                key={doc.id}
                className="flex items-center gap-3 px-2 py-2.5 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700/40 transition-colors"
              >
                <button
                  className="flex items-center gap-3 flex-1 min-w-0 text-left"
                  onClick={() => onOpen(doc)}
                >
                  <DocIcon type={doc.fileType} color={color} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold dark:text-white truncate">{doc.title}</p>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span
                        className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded"
                        style={{ backgroundColor: `${color}20`, color }}
                      >
                        {doc.fileType}
                      </span>
                      {doc.pageCount && (
                        <span className="text-xs text-brand-muted">
                          {complete ? 'Done ✓' : `p.${doc.lastPage}/${doc.pageCount}`}
                        </span>
                      )}
                      <span className="text-xs text-brand-muted">{fmtSize(doc.fileSizeBytes)}</span>
                    </div>
                    {doc.pageCount && (
                      <div className="w-full h-1 bg-gray-200 dark:bg-gray-600 rounded-full mt-1.5">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: complete ? '#10B981' : color,
                          }}
                        />
                      </div>
                    )}
                  </div>
                  <span className="text-gray-400 text-sm shrink-0">›</span>
                </button>
                <div className="flex items-center gap-1 shrink-0">
                  {isConfirming ? (
                    <>
                      <button
                        onClick={() => {
                          deleteDocument(doc.id);
                          setConfirmDelete(null);
                        }}
                        className="text-xs bg-red-500 text-white px-2 py-1 rounded font-semibold"
                      >
                        Delete
                      </button>
                      <button
                        onClick={() => setConfirmDelete(null)}
                        className="text-xs text-brand-muted px-1"
                      >
                        ✕
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setConfirmDelete(doc.id)}
                      className="text-gray-300 hover:text-red-400 text-lg leading-none px-1"
                    >
                      ×
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && search && (
            <p className="text-sm text-brand-muted text-center py-8">No matches.</p>
          )}
        </div>
      )}
    </div>
  );
}
