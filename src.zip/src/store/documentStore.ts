import { create } from 'zustand';
import { supabase } from '@/lib/supabase';
import type { Document } from '@/types';

const mapDoc = (t: Record<string, unknown>): Document => ({
  id: t.id as string,
  userId: t.user_id as string,
  title: t.title as string,
  filePath: t.file_path as string,
  fileSizeBytes: t.file_size_bytes as number,
  pageCount: t.page_count as number | null,
  lastPage: (t.last_page as number) ?? 1,
  fileType: t.file_type as 'pdf' | 'epub',
  createdAt: t.created_at as string,
});

interface DocumentStore {
  documents: Document[];
  loading: boolean;
  uploading: boolean;
  fetchAll: () => Promise<void>;
  uploadDocument: (file: File, title: string) => Promise<Document | null>;
  updateLastPage: (id: string, page: number) => Promise<void>;
  updateTitle: (id: string, title: string) => Promise<void>;
  deleteDocument: (id: string) => Promise<void>;
  getSignedUrl: (filePath: string) => Promise<string | null>;
}

export const useDocumentStore = create<DocumentStore>((set, get) => ({
  documents: [],
  loading: false,
  uploading: false,

  fetchAll: async () => {
    set({ loading: true });
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) {
      set({ documents: data.map(mapDoc), loading: false });
    } else {
      set({ loading: false });
    }
  },

  uploadDocument: async (file: File, title: string): Promise<Document | null> => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return null;

    set({ uploading: true });

    const ext = file.name.split('.').pop()?.toLowerCase() ?? 'pdf';
    const fileType = ext === 'epub' ? 'epub' : 'pdf';
    const uuid = crypto.randomUUID();
    const filePath = `${user.id}/${uuid}.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from('documents')
      .upload(filePath, file, { contentType: file.type, upsert: false });

    if (uploadError) {
      set({ uploading: false });
      console.error('Upload error:', uploadError);
      return null;
    }

    const { data, error: dbError } = await supabase
      .from('documents')
      .insert({
        user_id: user.id,
        title,
        file_path: filePath,
        file_size_bytes: file.size,
        file_type: fileType,
        last_page: 1,
        page_count: null,
      })
      .select()
      .single();

    set({ uploading: false });

    if (dbError || !data) {
      console.error('DB insert error:', dbError);
      return null;
    }

    const mapped = mapDoc(data);
    set((s) => ({ documents: [mapped, ...s.documents] }));
    return mapped;
  },

  updateLastPage: async (id: string, page: number) => {
    await supabase.from('documents').update({ last_page: page }).eq('id', id);
    set((s) => ({
      documents: s.documents.map((d) => (d.id === id ? { ...d, lastPage: page } : d)),
    }));
  },

  updateTitle: async (id: string, title: string) => {
    await supabase.from('documents').update({ title }).eq('id', id);
    set((s) => ({
      documents: s.documents.map((d) => (d.id === id ? { ...d, title } : d)),
    }));
  },

  deleteDocument: async (id: string) => {
    const doc = get().documents.find((d) => d.id === id);
    if (!doc) return;
    // Delete from storage
    await supabase.storage.from('documents').remove([doc.filePath]);
    // Delete from DB
    await supabase.from('documents').delete().eq('id', id);
    set((s) => ({ documents: s.documents.filter((d) => d.id !== id) }));
  },

  getSignedUrl: async (filePath: string): Promise<string | null> => {
    const { data, error } = await supabase.storage
      .from('documents')
      .createSignedUrl(filePath, 3600); // 1 hour
    if (error || !data) return null;
    return data.signedUrl;
  },
}));
