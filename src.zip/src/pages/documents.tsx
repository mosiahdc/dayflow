import { useState } from 'react';
import { useUIStore } from '@/store/uiStore';
import DocumentLibrary from '@/components/documents/DocumentLibrary';
import DocumentReader from '@/components/documents/DocumentReader';
import type { Document } from '@/types';

export default function DocumentsPage() {
  const { dismissDocsBadge } = useUIStore();
  const [openDoc, setOpenDoc] = useState<Document | null>(null);

  const handleOpen = (doc: Document) => {
    dismissDocsBadge();
    setOpenDoc(doc);
  };

  // Reader takes over the full viewport — rendered outside normal page flow
  if (openDoc) {
    return (
      <div
        className="fixed inset-0 z-50 bg-gray-900 flex flex-col"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <DocumentReader doc={openDoc} onClose={() => setOpenDoc(null)} />
      </div>
    );
  }

  // Library — scrollable, max width centered
  return (
    <div className="max-w-2xl mx-auto flex flex-col" style={{ minHeight: 'calc(100vh - 130px)' }}>
      <DocumentLibrary onOpen={handleOpen} />
    </div>
  );
}
